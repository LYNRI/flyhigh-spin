import { useEffect, useState } from "react";
import Link from "next/link";
import { useAviatorSocket } from "../lib/useAviatorSocket";

const PHASE_LABEL = {
  connecting: "Connecting…",
  betting: "Place your bet",
  flying: "In flight",
  crashed: "Crashed",
};

export default function Aviator() {
  const { connected, phase, multiplier, crashPoint, history, lastResult, activeBetId, placeBet, cashOut } =
    useAviatorSocket();
  const [stake, setStake] = useState(50);
  const [autoCashout, setAutoCashout] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);

  useEffect(() => {
    setLoggedIn(Boolean(window.localStorage.getItem("access_token")));
  }, []);

  function handlePlaceBet() {
    placeBet(Number(stake), autoCashout ? Number(autoCashout) : null);
  }

  function handleCashOut() {
    if (activeBetId) cashOut(activeBetId, multiplier);
  }

  // Flight path curve: x = time-ish progress, y = multiplier height, purely illustrative.
  const progress = Math.min((multiplier - 1) / 9, 1); // caps the visual climb around 10x
  const pathX = 40 + progress * 520;
  const pathY = 260 - progress * 200;

  return (
    <div className="max-w-md mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs uppercase tracking-wide text-muted">{PHASE_LABEL[phase] || phase}</span>
        <span className={`text-xs ${connected ? "text-trail" : "text-danger"}`}>
          {connected ? "Live" : "Disconnected"}
        </span>
      </div>

      {/* Dashboard below is visible to everyone, logged in or not */}
      <div className="relative bg-panel border border-edge rounded-lg h-72 overflow-hidden mb-4">
        <svg viewBox="0 0 600 300" className="absolute inset-0 w-full h-full">
          <line x1="40" y1="260" x2="560" y2="260" stroke="#26314E" strokeWidth="1" />
          <line x1="40" y1="40" x2="40" y2="260" stroke="#26314E" strokeWidth="1" />
          {phase === "flying" && (
            <path
              d={`M 40 260 Q ${pathX * 0.6} 260 ${pathX} ${pathY}`}
              stroke="#4CC9F0"
              strokeWidth="3"
              fill="none"
            />
          )}
          {phase === "flying" && <circle cx={pathX} cy={pathY} r="5" fill="#F2B705" />}
        </svg>

        <div className="absolute inset-0 flex items-center justify-center">
          <span className={`font-hud text-6xl font-bold ${phase === "crashed" ? "text-danger" : "text-white"}`}>
            {phase === "crashed" ? `${crashPoint}x` : `${multiplier.toFixed(2)}x`}
          </span>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto mb-4 pb-1">
        {history.map((h, i) => (
          <span
            key={i}
            className={`shrink-0 text-xs font-hud px-2 py-1 rounded ${
              h >= 2 ? "bg-trail/20 text-trail" : "bg-danger/20 text-danger"
            }`}
          >
            {h}x
          </span>
        ))}
      </div>

      {/* Betting itself requires an account — spectators see everything above,
          but placing a stake needs a wallet behind it. */}
      {loggedIn ? (
        <div className="bg-panel border border-edge rounded-lg p-4 space-y-3">
          <div className="flex gap-3">
            <label className="flex-1">
              <span className="block text-xs text-muted mb-1">Stake (KES)</span>
              <input
                type="number"
                min="10"
                value={stake}
                onChange={(e) => setStake(e.target.value)}
                className="w-full bg-panel2 border border-edge rounded px-3 py-2"
              />
            </label>
            <label className="flex-1">
              <span className="block text-xs text-muted mb-1">Auto cash out (optional)</span>
              <input
                type="number"
                step="0.1"
                min="1.01"
                placeholder="e.g. 2.0"
                value={autoCashout}
                onChange={(e) => setAutoCashout(e.target.value)}
                className="w-full bg-panel2 border border-edge rounded px-3 py-2"
              />
            </label>
          </div>

          {phase === "betting" ? (
            <button onClick={handlePlaceBet} className="w-full bg-gold text-base font-semibold rounded py-3">
              Place bet
            </button>
          ) : (
            <button
              onClick={handleCashOut}
              disabled={phase !== "flying" || !activeBetId}
              className="w-full bg-trail text-base font-semibold rounded py-3 disabled:opacity-40"
            >
              Cash out {phase === "flying" ? `@ ${multiplier.toFixed(2)}x` : ""}
            </button>
          )}

          {lastResult && (
            <p className={`text-sm ${lastResult.ok ? "text-trail" : "text-danger"}`}>{lastResult.message}</p>
          )}
        </div>
      ) : (
        <div className="bg-panel border border-edge rounded-lg p-4 text-center space-y-3">
          <p className="text-sm text-muted">Watching live — log in to place a bet.</p>
          <div className="flex gap-3">
            <Link href="/login" className="flex-1 bg-panel2 border border-edge text-sm rounded py-2.5">
              Log in
            </Link>
            <Link href="/register" className="flex-1 bg-gold text-base text-sm font-semibold rounded py-2.5">
              Sign up
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}

import { useState } from "react";
import { useRouter } from "next/router";
import Link from "next/link";
import { api } from "../lib/api";
import { Field } from "../components/Field";

export default function Login() {
  const router = useRouter();
  const [form, setForm] = useState({ phone_number: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function update(field) {
    return (e) => setForm({ ...form, [field]: e.target.value });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await api.login(form);
      router.push(`/verify-otp?phone=${encodeURIComponent(form.phone_number)}&purpose=login`);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen px-4">
      <div className="w-full max-w-sm">
        <h1 className="font-hud text-3xl font-semibold text-trail mb-1">Log in</h1>
        <p className="text-muted text-sm mb-6">We'll text you a code to confirm it's you.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Phone number" placeholder="2547XXXXXXXX" value={form.phone_number} onChange={update("phone_number")} />
          <Field label="Password" type="password" value={form.password} onChange={update("password")} />

          {error && <p className="text-danger text-sm">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gold text-base font-semibold rounded py-2.5 mt-2 disabled:opacity-50"
          >
            {loading ? "Sending code…" : "Continue"}
          </button>
        </form>

        <p className="text-muted text-sm mt-6">
          New here? <Link href="/register" className="text-trail">Create an account</Link>
        </p>
      </div>
    </div>
  );
}

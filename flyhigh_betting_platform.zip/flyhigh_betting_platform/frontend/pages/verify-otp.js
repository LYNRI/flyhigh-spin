import { useState } from "react";
import { useRouter } from "next/router";
import { api, setTokens } from "../lib/api";
import { Field } from "../components/Field";

export default function VerifyOtp() {
  const router = useRouter();
  const { phone, purpose } = router.query;
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const data = await api.verifyOtp({ phone_number: phone, code, purpose });
      setTokens({ access: data.access, refresh: data.refresh });
      router.push("/aviator");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen px-4">
      <div className="w-full max-w-sm">
        <h1 className="font-hud text-3xl font-semibold text-trail mb-1">Enter your code</h1>
        <p className="text-muted text-sm mb-6">We sent a 6-digit code to {phone}.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Field
            label="Verification code"
            inputMode="numeric"
            maxLength={6}
            value={code}
            onChange={(e) => setCode(e.target.value)}
          />
          {error && <p className="text-danger text-sm">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gold text-base font-semibold rounded py-2.5 mt-2 disabled:opacity-50"
          >
            {loading ? "Verifying…" : "Verify"}
          </button>
        </form>
      </div>
    </div>
  );
}

import { useEffect } from "react";
import { useRouter } from "next/router";

export default function Home() {
  const router = useRouter();
  useEffect(() => {
    // The Aviator dashboard is public — everyone lands there whether logged
    // in or not. Login is only required when they try to place a bet.
    router.replace("/aviator");
  }, [router]);

  return (
    <div className="flex items-center justify-center h-screen">
      <span className="text-muted font-hud">Loading…</span>
    </div>
  );
}

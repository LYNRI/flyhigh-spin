import { useState } from "react";
import { api } from "../lib/api";

const SYMBOL_EMOJI = {
  cherry: "🍒", lemon: "🍋", bell: "🔔", star: "⭐", seven: "7️⃣", diamond: "💎",
};

export default function Spin() {
  const [stake, setStake] = useState(20);
  const [reels, setReels] = useState(["cherry", "lemon", "bell"]);
  const [spinning, setSpinning] = useState(false);
  const [lastPayout, setLastPayout] = useState(null);
  const [error, setError] = useState("");

  async function handleSpin() {
    setSpinning(true);
    setError("");
    try {
      const result = await api.spinPlay(Number(stake));
      setReels(result.reels);
      setLastPayout(result.payout);
    } catch (err) {
      setError(err.message);
    } finally {
      setSpinning(false);
    }
  }

  return (
    <div className="max-w-md mx-auto px-4 py-6">
      <h1 className="font-hud text-2xl font-semibold text-gold mb-4">Spin</h1>

      <div className="bg-panel border border-edge rounded-lg p-6 mb-4">
        <div className="flex justify-center gap-4">
          {reels.map((symbol, i) => (
            <div
              key={i}
              className={`w-20 h-20 flex items-center justify-center text-4xl bg-panel2 border border-edge rounded-lg ${
                spinning ? "animate-pulse" : ""
              }`}
            >
              {SYMBOL_EMOJI[symbol] || "❔"}
            </div>
          ))}
        </div>

        {lastPayout !== null && !spinning && (
          <p className={`text-center mt-4 font-hud text-lg ${Number(lastPayout) > 0 ? "text-gold" : "text-muted"}`}>
            {Number(lastPayout) > 0 ? `Won KES ${lastPayout}` : "No win this round"}
          </p>
        )}
      </div>

      <div className="bg-panel border border-edge rounded-lg p-4 space-y-3">
        <label className="block">
          <span className="block text-xs text-muted mb-1">Stake (KES)</span>
          <input
            type="number"
            min="10"
            value={stake}
            onChange={(e) => setStake(e.target.value)}
            className="w-full bg-panel2 border border-edge rounded px-3 py-2"
          />
        </label>

        {error && <p className="text-danger text-sm">{error}</p>}

        <button
          onClick={handleSpin}
          disabled={spinning}
          className="w-full bg-gold text-base font-semibold rounded py-3 disabled:opacity-50"
        >
          {spinning ? "Spinning…" : "Spin"}
        </button>
      </div>
    </div>
  );
}

import { useState } from "react";
import { api } from "../lib/api";

export default function Wallet() {
  const [depositAmount, setDepositAmount] = useState(100);
  const [withdrawAmount, setWithdrawAmount] = useState(100);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleDeposit(e) {
    e.preventDefault();
    setError("");
    setStatus("");
    setLoading(true);
    try {
      const result = await api.deposit(Number(depositAmount));
      setStatus(result.message);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleWithdraw(e) {
    e.preventDefault();
    setError("");
    setStatus("");
    setLoading(true);
    try {
      const result = await api.withdraw(Number(withdrawAmount));
      setStatus(result.message);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-md mx-auto px-4 py-6 space-y-6">
      <h1 className="font-hud text-2xl font-semibold text-gold">Wallet</h1>

      {status && <p className="text-trail text-sm bg-trail/10 border border-trail/30 rounded px-3 py-2">{status}</p>}
      {error && <p className="text-danger text-sm bg-danger/10 border border-danger/30 rounded px-3 py-2">{error}</p>}

      <form onSubmit={handleDeposit} className="bg-panel border border-edge rounded-lg p-4 space-y-3">
        <h2 className="font-hud text-lg">Deposit via M-Pesa</h2>
        <p className="text-xs text-muted">You'll get an STK push prompt on your phone to enter your M-Pesa PIN.</p>
        <label className="block">
          <span className="block text-xs text-muted mb-1">Amount (KES)</span>
          <input
            type="number"
            min="10"
            value={depositAmount}
            onChange={(e) => setDepositAmount(e.target.value)}
            className="w-full bg-panel2 border border-edge rounded px-3 py-2"
          />
        </label>
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-gold text-base font-semibold rounded py-2.5 disabled:opacity-50"
        >
          {loading ? "Sending…" : "Send STK push"}
        </button>
      </form>

      <form onSubmit={handleWithdraw} className="bg-panel border border-edge rounded-lg p-4 space-y-3">
        <h2 className="font-hud text-lg">Withdraw to M-Pesa</h2>
        <label className="block">
          <span className="block text-xs text-muted mb-1">Amount (KES)</span>
          <input
            type="number"
            min="50"
            value={withdrawAmount}
            onChange={(e) => setWithdrawAmount(e.target.value)}
            className="w-full bg-panel2 border border-edge rounded px-3 py-2"
          />
        </label>
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-trail text-base font-semibold rounded py-2.5 disabled:opacity-50"
        >
          {loading ? "Submitting…" : "Withdraw"}
        </button>
      </form>
    </div>
  );
}

import { useState } from "react";
import { useRouter } from "next/router";
import Link from "next/link";
import { api } from "../lib/api";
import { Field } from "../components/Field";

export default function Register() {
  const router = useRouter();
  const [form, setForm] = useState({ phone_number: "", username: "", password: "", date_of_birth: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function update(field) {
    return (e) => setForm({ ...form, [field]: e.target.value });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await api.register(form);
      router.push(`/verify-otp?phone=${encodeURIComponent(form.phone_number)}&purpose=registration`);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen px-4">
      <div className="w-full max-w-sm">
        <h1 className="font-hud text-3xl font-semibold text-trail mb-1">Create account</h1>
        <p className="text-muted text-sm mb-6">Must be 18 or older to register.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Phone number" placeholder="2547XXXXXXXX" value={form.phone_number} onChange={update("phone_number")} />
          <Field label="Username" value={form.username} onChange={update("username")} />
          <Field label="Password" type="password" value={form.password} onChange={update("password")} />
          <Field label="Date of birth" type="date" value={form.date_of_birth} onChange={update("date_of_birth")} />

          {error && <p className="text-danger text-sm">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gold text-base font-semibold rounded py-2.5 mt-2 disabled:opacity-50"
          >
            {loading ? "Creating…" : "Create account"}
          </button>
        </form>

        <p className="text-muted text-sm mt-6">
          Already have an account? <Link href="/login" className="text-trail">Log in</Link>
        </p>
      </div>
    </div>
  );
}

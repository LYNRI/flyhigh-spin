import "../styles/globals.css";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { clearTokens } from "../lib/api";
import { useBalance } from "../lib/useBalance";

export default function App({ Component, pageProps }) {
  const router = useRouter();
  const [loggedIn, setLoggedIn] = useState(false);

  useEffect(() => {
    setLoggedIn(Boolean(window.localStorage.getItem("access_token")));
  }, [router.pathname]);

  const { balance, refresh } = useBalance(loggedIn);

  // Wallet and game pages change the balance server-side; re-check whenever
  // the route changes (e.g. navigating away from wallet after a deposit).
  useEffect(() => {
    refresh();
  }, [router.pathname, refresh]);

  function logout() {
    clearTokens();
    router.push("/login");
  }

  return (
    <div className="min-h-screen bg-base text-white font-body">
      <nav className="flex items-center justify-between px-4 py-3 border-b border-edge bg-panel">
        <div className="flex items-center gap-5">
          <span className="font-hud text-trail font-semibold tracking-tight">FLYHIGH</span>
          <Link href="/aviator" className="text-sm text-muted hover:text-white">Aviator</Link>
          <Link href="/spin" className="text-sm text-muted hover:text-white">Spin</Link>
          <Link href="/wallet" className="text-sm text-muted hover:text-white">Wallet</Link>
        </div>
        <div className="flex items-center gap-4">
          {loggedIn ? (
            <>
              <span className="font-hud text-sm text-gold">
                {balance !== null ? `KES ${Number(balance).toLocaleString()}` : "…"}
              </span>
              <button onClick={logout} className="text-sm text-muted hover:text-danger">Log out</button>
            </>
          ) : (
            <>
              <Link href="/login" className="text-sm text-muted hover:text-white">Log in</Link>
              <Link href="/register" className="text-sm bg-gold text-base font-semibold rounded px-3 py-1.5">
                Sign up
              </Link>
            </>
          )}
        </div>
      </nav>
      <Component {...pageProps} />
    </div>
  );
}

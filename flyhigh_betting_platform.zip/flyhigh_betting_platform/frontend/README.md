# Betting Platform — Frontend

Next.js + Tailwind SPA for the Django betting API: phone+OTP auth, Aviator
(live WebSocket HUD), Spin/slots, and M-Pesa wallet deposit/withdraw.

## Getting started

```bash
cp .env.local.example .env.local   # point at your backend if not localhost:8000
npm install
npm run dev
```

Visit http://localhost:3000 — you'll land on `/login` until you have a token.

## Structure

```
pages/
  login.js, register.js, verify-otp.js   phone + password + SMS-OTP flow
  aviator.js                              live crash game (WebSocket)
  spin.js                                 slots (REST, instant result)
  wallet.js                               M-Pesa deposit/withdraw
lib/
  api.js               fetch wrapper: JWT storage, auto-refresh on 401
  useAviatorSocket.js  WebSocket connection + round state machine
  useBalance.js         polls wallet balance for the nav bar
```

## Design direction

Dark cockpit/HUD aesthetic (navy base, cyan "flight trail" accent, gold for
money) rather than a generic SaaS-card look — leans into the Aviator
subject matter. Space Grotesk for numeric/display text, Inter for body copy.

## What's still rough

- The Aviator bet panel assumes one open bet per round; extend `useAviatorSocket`
  if you want to support the "two simultaneous bet slots" pattern common in
  crash games.
- No toast/notification system yet — errors render inline per-form.
- No SSR/auth guard middleware — pages check `localStorage` client-side only,
  so add a proper auth guard (e.g. `getServerSideProps` or a route wrapper)
  before shipping.
- Styling is functional, not final — treat it as a strong starting direction.

export function Field({ label, ...props }) {
  return (
    <label className="block">
      <span className="block text-sm text-muted mb-1">{label}</span>
      <input
        {...props}
        required
        className="w-full bg-panel border border-edge rounded px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-trail"
      />
    </label>
  );
}

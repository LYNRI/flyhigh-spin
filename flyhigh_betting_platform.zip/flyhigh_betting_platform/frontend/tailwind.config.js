/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./pages/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        base: "#0B1220",       // near-black navy background
        panel: "#141B2E",       // card/panel surface
        panel2: "#1B2440",      // slightly raised surface
        trail: "#4CC9F0",       // flight-path / live-data cyan
        gold: "#F2B705",        // wins, money, primary CTA
        danger: "#E4572E",      // crash / loss
        muted: "#8B96AC",       // secondary text
        edge: "#26314E",        // borders/dividers
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["Inter", "sans-serif"],
      },
    },
  },
  plugins: [],
};

# Betting Platform — Full Project (Backend + Frontend)

```
betting_platform_full/
  backend/     Django API — accounts (OTP auth), wallet (M-Pesa), Aviator, Spin
  frontend/    Next.js + Tailwind SPA consuming the API above
```

## Run it

**Backend** (see `backend/README.md` for full detail):

```bash
cd backend
cp .env.example .env        # fill in DB/Redis/M-Pesa/Africa's Talking credentials
docker compose up --build
docker compose exec web python manage.py migrate
docker compose exec web python manage.py createsuperuser
```

This brings up Postgres, Redis, the Django API (Daphne, for WebSocket
support), the Celery worker, and the Aviator round engine — all as separate
containers in `backend/docker-compose.yml`.

**Frontend** (see `frontend/README.md` for full detail):

```bash
cd frontend
cp .env.local.example .env.local   # points at http://localhost:8000 by default
npm install
npm run dev
```

Visit http://localhost:3000.

## Before this touches real money

1. Get a **Betting Control and Licensing Board (BCLB)** license — this also
   gates Safaricom's production Daraja API access.
2. Load-test the Aviator WebSocket path with many concurrent connections —
   one dealer loop needs to broadcast cleanly to everyone.
3. Get a security review / penetration test done. This codebase follows good
   practice (hashed OTPs, atomic wallet transactions, idempotent M-Pesa
   callbacks) but hasn't been audited.
4. Wire up real Africa's Talking and Safaricom Daraja credentials and test
   the full deposit → bet → cashout → withdraw loop in sandbox first.

See each subproject's own README for what's implemented vs. still rough.

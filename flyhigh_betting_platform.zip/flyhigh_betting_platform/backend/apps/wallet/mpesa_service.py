import base64
import requests
from datetime import datetime
from django.conf import settings

MPESA = settings.MPESA
BASE_URL = (
    "https://sandbox.safaricom.co.ke" if MPESA["ENV"] == "sandbox" else "https://api.safaricom.co.ke"
)


def _get_access_token() -> str:
    resp = requests.get(
        f"{BASE_URL}/oauth/v1/generate?grant_type=client_credentials",
        auth=(MPESA["CONSUMER_KEY"], MPESA["CONSUMER_SECRET"]),
        timeout=15,
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def _stk_password(timestamp: str) -> str:
    raw = f"{MPESA['SHORTCODE']}{MPESA['PASSKEY']}{timestamp}"
    return base64.b64encode(raw.encode()).decode()


def initiate_stk_push(phone_number: str, amount: int, account_reference: str) -> dict:
    """
    Deposit flow: sends an STK push prompt to the user's phone.
    phone_number must be in 2547XXXXXXXX format (no leading +).
    """
    token = _get_access_token()
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")

    payload = {
        "BusinessShortCode": MPESA["SHORTCODE"],
        "Password": _stk_password(timestamp),
        "Timestamp": timestamp,
        "TransactionType": "CustomerPayBillOnline",
        "Amount": amount,
        "PartyA": phone_number,
        "PartyB": MPESA["SHORTCODE"],
        "PhoneNumber": phone_number,
        "CallBackURL": f"{MPESA['CALLBACK_BASE_URL']}/api/wallet/mpesa/stk-callback/",
        "AccountReference": account_reference,
        "TransactionDesc": "Wallet deposit",
    }
    resp = requests.post(
        f"{BASE_URL}/mpesa/stkpush/v1/processrequest",
        json=payload,
        headers={"Authorization": f"Bearer {token}"},
        timeout=15,
    )
    resp.raise_for_status()
    return resp.json()  # contains CheckoutRequestID to store against the pending Transaction


def initiate_b2c_payment(phone_number: str, amount: int, remarks: str) -> dict:
    """Withdrawal flow: pays out from the business paybill to the customer's M-Pesa."""
    token = _get_access_token()

    payload = {
        "InitiatorName": MPESA["B2C_INITIATOR_NAME"],
        "SecurityCredential": MPESA["B2C_SECURITY_CREDENTIAL"],
        "CommandID": "BusinessPayment",
        "Amount": amount,
        "PartyA": MPESA["SHORTCODE"],
        "PartyB": phone_number,
        "Remarks": remarks,
        "QueueTimeOutURL": f"{MPESA['CALLBACK_BASE_URL']}/api/wallet/mpesa/b2c-timeout/",
        "ResultURL": f"{MPESA['CALLBACK_BASE_URL']}/api/wallet/mpesa/b2c-result/",
        "Occasion": "Withdrawal",
    }
    resp = requests.post(
        f"{BASE_URL}/mpesa/b2c/v1/paymentrequest",
        json=payload,
        headers={"Authorization": f"Bearer {token}"},
        timeout=15,
    )
    resp.raise_for_status()
    return resp.json()

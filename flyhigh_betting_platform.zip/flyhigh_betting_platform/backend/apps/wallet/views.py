import uuid
from decimal import Decimal
from django.db import transaction as db_transaction
from rest_framework import status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Wallet, Transaction, MpesaTransaction
from .mpesa_service import initiate_stk_push, initiate_b2c_payment

MIN_DEPOSIT = 10
MIN_WITHDRAWAL = 50


class BalanceView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        wallet, _ = Wallet.objects.get_or_create(user=request.user)
        return Response({
            "balance": str(wallet.balance),
            "locked_balance": str(wallet.locked_balance),
            "available_balance": str(wallet.available_balance()),
        })


class DepositView(APIView):
    """Kicks off an STK push. Balance is only credited once the callback confirms success."""
    permission_classes = [IsAuthenticated]
    throttle_scope = "mpesa_stk"

    def post(self, request):
        amount = int(request.data.get("amount", 0))
        if amount < MIN_DEPOSIT:
            return Response({"detail": f"Minimum deposit is KES {MIN_DEPOSIT}."}, status=400)

        wallet, _ = Wallet.objects.get_or_create(user=request.user)
        reference = f"DEP-{uuid.uuid4().hex[:12]}"

        txn = Transaction.objects.create(
            wallet=wallet, type="deposit", amount=amount, status="pending", reference=reference,
        )

        try:
            result = initiate_stk_push(
                phone_number=request.user.phone_number, amount=amount, account_reference=reference
            )
        except Exception as exc:
            txn.status = "failed"
            txn.save(update_fields=["status"])
            return Response({"detail": "Could not reach M-Pesa. Try again."}, status=502)

        MpesaTransaction.objects.create(
            transaction=txn,
            direction="stk_push",
            checkout_request_id=result.get("CheckoutRequestID"),
            phone_number=request.user.phone_number,
            amount=amount,
        )
        return Response({"message": "Check your phone to complete the M-Pesa payment.", "reference": reference})


class WithdrawView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        amount = int(request.data.get("amount", 0))
        if amount < MIN_WITHDRAWAL:
            return Response({"detail": f"Minimum withdrawal is KES {MIN_WITHDRAWAL}."}, status=400)

        wallet = Wallet.objects.select_for_update().get(user=request.user)
        if wallet.available_balance() < amount:
            return Response({"detail": "Insufficient balance."}, status=400)

        reference = f"WD-{uuid.uuid4().hex[:12]}"

        with db_transaction.atomic():
            wallet.balance -= amount
            wallet.save(update_fields=["balance"])
            txn = Transaction.objects.create(
                wallet=wallet, type="withdrawal", amount=amount, status="pending", reference=reference,
            )

        try:
            result = initiate_b2c_payment(request.user.phone_number, amount, remarks=reference)
        except Exception:
            # reverse the debit since the B2C call itself failed to submit
            with db_transaction.atomic():
                wallet.balance += amount
                wallet.save(update_fields=["balance"])
                txn.status = "failed"
                txn.save(update_fields=["status"])
            return Response({"detail": "Withdrawal failed to submit. Balance restored."}, status=502)

        MpesaTransaction.objects.create(
            transaction=txn, direction="b2c",
            conversation_id=result.get("ConversationID"),
            phone_number=request.user.phone_number, amount=amount,
        )
        return Response({"message": "Withdrawal submitted.", "reference": reference})


class MpesaSTKCallbackView(APIView):
    """
    Safaricom posts here after the user enters their M-Pesa PIN.
    Must be idempotent — Safaricom can retry callbacks.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        body = request.data.get("Body", {}).get("stkCallback", {})
        checkout_id = body.get("CheckoutRequestID")
        result_code = body.get("ResultCode")

        mpesa_txn = MpesaTransaction.objects.filter(checkout_request_id=checkout_id).select_related(
            "transaction", "transaction__wallet"
        ).first()
        if not mpesa_txn or mpesa_txn.transaction.status != "pending":
            return Response({"ResultCode": 0, "ResultDesc": "Already processed or unknown"})

        mpesa_txn.raw_callback = body
        mpesa_txn.result_code = result_code
        mpesa_txn.result_description = body.get("ResultDesc")

        if result_code == 0:
            items = {i["Name"]: i.get("Value") for i in body.get("CallbackMetadata", {}).get("Item", [])}
            mpesa_txn.mpesa_receipt_number = items.get("MpesaReceiptNumber")
            mpesa_txn.save()

            with db_transaction.atomic():
                wallet = Wallet.objects.select_for_update().get(pk=mpesa_txn.transaction.wallet_id)
                wallet.balance += mpesa_txn.transaction.amount
                wallet.save(update_fields=["balance"])
                mpesa_txn.transaction.status = "completed"
                mpesa_txn.transaction.save(update_fields=["status"])
        else:
            mpesa_txn.save()
            mpesa_txn.transaction.status = "failed"
            mpesa_txn.transaction.save(update_fields=["status"])

        return Response({"ResultCode": 0, "ResultDesc": "Accepted"})


class MpesaB2CResultView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        result = request.data.get("Result", {})
        conversation_id = result.get("ConversationID")
        result_code = result.get("ResultCode")

        mpesa_txn = MpesaTransaction.objects.filter(conversation_id=conversation_id).select_related(
            "transaction", "transaction__wallet"
        ).first()
        if not mpesa_txn or mpesa_txn.transaction.status != "pending":
            return Response({"ResultCode": 0, "ResultDesc": "Already processed or unknown"})

        mpesa_txn.raw_callback = result
        mpesa_txn.result_code = result_code
        mpesa_txn.result_description = result.get("ResultDesc")
        mpesa_txn.save()

        if result_code == 0:
            mpesa_txn.transaction.status = "completed"
        else:
            # payout failed after we'd already debited the wallet — refund it
            with db_transaction.atomic():
                wallet = Wallet.objects.select_for_update().get(pk=mpesa_txn.transaction.wallet_id)
                wallet.balance += mpesa_txn.transaction.amount
                wallet.save(update_fields=["balance"])
                mpesa_txn.transaction.status = "reversed"
        mpesa_txn.transaction.save(update_fields=["status"])

        return Response({"ResultCode": 0, "ResultDesc": "Accepted"})


class MpesaB2CTimeoutView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        # Log for ops review; the ResultURL callback is the authoritative outcome.
        return Response({"ResultCode": 0, "ResultDesc": "Accepted"})

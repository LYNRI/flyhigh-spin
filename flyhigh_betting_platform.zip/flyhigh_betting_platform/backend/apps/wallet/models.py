import uuid
from django.conf import settings
from django.db import models


class Wallet(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="wallet")
    balance = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    locked_balance = models.DecimalField(max_digits=14, decimal_places=2, default=0)  # funds tied up in open bets
    updated_at = models.DateTimeField(auto_now=True)

    def available_balance(self):
        return self.balance - self.locked_balance


class Transaction(models.Model):
    """
    Append-only ledger. Never mutate a row after creation — corrections are
    new offsetting rows. This is what you reconcile against M-Pesa statements.
    """
    TYPE_CHOICES = [
        ("deposit", "Deposit"),
        ("withdrawal", "Withdrawal"),
        ("bet_stake", "Bet Stake"),
        ("bet_payout", "Bet Payout"),
        ("bonus", "Bonus"),
        ("reversal", "Reversal"),
    ]
    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("completed", "Completed"),
        ("failed", "Failed"),
        ("reversed", "Reversed"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    wallet = models.ForeignKey(Wallet, on_delete=models.PROTECT, related_name="transactions")
    type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    amount = models.DecimalField(max_digits=14, decimal_places=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")
    reference = models.CharField(max_length=64, unique=True)  # idempotency key
    metadata = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [models.Index(fields=["wallet", "created_at"])]


class MpesaTransaction(models.Model):
    """Raw record of every Daraja API interaction, for reconciliation and audit."""
    DIRECTION_CHOICES = [("stk_push", "STK Push (Deposit)"), ("b2c", "B2C (Withdrawal)")]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    transaction = models.ForeignKey(Transaction, on_delete=models.SET_NULL, null=True, related_name="mpesa_records")
    direction = models.CharField(max_length=20, choices=DIRECTION_CHOICES)
    checkout_request_id = models.CharField(max_length=64, blank=True, null=True)
    conversation_id = models.CharField(max_length=64, blank=True, null=True)
    mpesa_receipt_number = models.CharField(max_length=32, blank=True, null=True)
    phone_number = models.CharField(max_length=15)
    amount = models.DecimalField(max_digits=14, decimal_places=2)
    raw_callback = models.JSONField(default=dict, blank=True)
    result_code = models.IntegerField(null=True, blank=True)
    result_description = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

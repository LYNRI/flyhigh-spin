from django.urls import path
from .views import (
    BalanceView, DepositView, WithdrawView,
    MpesaSTKCallbackView, MpesaB2CResultView, MpesaB2CTimeoutView,
)

urlpatterns = [
    path("balance/", BalanceView.as_view(), name="wallet-balance"),
    path("deposit/", DepositView.as_view(), name="deposit"),
    path("withdraw/", WithdrawView.as_view(), name="withdraw"),
    path("mpesa/stk-callback/", MpesaSTKCallbackView.as_view(), name="mpesa-stk-callback"),
    path("mpesa/b2c-result/", MpesaB2CResultView.as_view(), name="mpesa-b2c-result"),
    path("mpesa/b2c-timeout/", MpesaB2CTimeoutView.as_view(), name="mpesa-b2c-timeout"),
]

import uuid

import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="Wallet",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("balance", models.DecimalField(decimal_places=2, default=0, max_digits=14)),
                ("locked_balance", models.DecimalField(decimal_places=2, default=0, max_digits=14)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "user",
                    models.OneToOneField(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="wallet",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
        ),
        migrations.CreateModel(
            name="Transaction",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                (
                    "type",
                    models.CharField(
                        choices=[
                            ("deposit", "Deposit"),
                            ("withdrawal", "Withdrawal"),
                            ("bet_stake", "Bet Stake"),
                            ("bet_payout", "Bet Payout"),
                            ("bonus", "Bonus"),
                            ("reversal", "Reversal"),
                        ],
                        max_length=20,
                    ),
                ),
                ("amount", models.DecimalField(decimal_places=2, max_digits=14)),
                (
                    "status",
                    models.CharField(
                        choices=[
                            ("pending", "Pending"),
                            ("completed", "Completed"),
                            ("failed", "Failed"),
                            ("reversed", "Reversed"),
                        ],
                        default="pending",
                        max_length=20,
                    ),
                ),
                ("reference", models.CharField(max_length=64, unique=True)),
                ("metadata", models.JSONField(blank=True, default=dict)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                (
                    "wallet",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.PROTECT,
                        related_name="transactions",
                        to="wallet.wallet",
                    ),
                ),
            ],
        ),
        migrations.CreateModel(
            name="MpesaTransaction",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                (
                    "direction",
                    models.CharField(
                        choices=[("stk_push", "STK Push (Deposit)"), ("b2c", "B2C (Withdrawal)")],
                        max_length=20,
                    ),
                ),
                ("checkout_request_id", models.CharField(blank=True, max_length=64, null=True)),
                ("conversation_id", models.CharField(blank=True, max_length=64, null=True)),
                ("mpesa_receipt_number", models.CharField(blank=True, max_length=32, null=True)),
                ("phone_number", models.CharField(max_length=15)),
                ("amount", models.DecimalField(decimal_places=2, max_digits=14)),
                ("raw_callback", models.JSONField(blank=True, default=dict)),
                ("result_code", models.IntegerField(blank=True, null=True)),
                ("result_description", models.CharField(blank=True, max_length=255, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                (
                    "transaction",
                    models.ForeignKey(
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name="mpesa_records",
                        to="wallet.transaction",
                    ),
                ),
            ],
        ),
        migrations.AddIndex(
            model_name="transaction",
            index=models.Index(fields=["wallet", "created_at"], name="wallet_txn_wallet_created_idx"),
        ),
    ]

"""
Africa's Talking SMS gateway — used to deliver OTP codes.
Docs: https://developers.africastalking.com/docs/sms/overview
"""
import requests
from django.conf import settings

AT_ENV = getattr(settings, "AFRICAS_TALKING", {})
SANDBOX_URL = "https://api.sandbox.africastalking.com/version1/messaging"
LIVE_URL = "https://api.africastalking.com/version1/messaging"


class SMSDeliveryError(Exception):
    pass


def send_sms(phone_number: str, message: str) -> dict:
    """
    phone_number must be in international format, e.g. +2547XXXXXXXX.
    Sandbox username is always 'sandbox'; switch AT_ENV['ENV'] to 'production'
    once you have a live Africa's Talking account and shortcode/sender ID.
    """
    url = SANDBOX_URL if AT_ENV.get("ENV", "sandbox") == "sandbox" else LIVE_URL

    payload = {
        "username": AT_ENV.get("USERNAME", "sandbox"),
        "to": phone_number,
        "message": message,
    }
    if AT_ENV.get("SENDER_ID"):
        payload["from"] = AT_ENV["SENDER_ID"]

    headers = {
        "apiKey": AT_ENV.get("API_KEY", ""),
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json",
    }

    resp = requests.post(url, data=payload, headers=headers, timeout=10)
    resp.raise_for_status()
    data = resp.json()

    recipients = data.get("SMSMessageData", {}).get("Recipients", [])
    if not recipients or recipients[0].get("status") != "Success":
        raise SMSDeliveryError(f"Africa's Talking rejected the message: {data}")

    return data

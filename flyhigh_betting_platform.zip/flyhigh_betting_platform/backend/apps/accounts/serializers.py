from django.contrib.auth import get_user_model
from django.utils import timezone
from datetime import timedelta
from rest_framework import serializers

User = get_user_model()

LOCKOUT_THRESHOLD = 5
LOCKOUT_DURATION_MIN = 15


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=10)

    class Meta:
        model = User
        fields = ["phone_number", "username", "password", "date_of_birth"]

    def validate_date_of_birth(self, value):
        age = (timezone.now().date() - value).days // 365
        if age < 18:
            raise serializers.ValidationError("You must be 18 or older to register.")
        return value

    def create(self, validated_data):
        password = validated_data.pop("password")
        user = User(**validated_data)
        user.set_password(password)
        user.is_active = False  # activated once phone OTP is verified
        user.save()
        return user


class LoginSerializer(serializers.Serializer):
    phone_number = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        try:
            user = User.objects.get(phone_number=attrs["phone_number"])
        except User.DoesNotExist:
            raise serializers.ValidationError("Invalid credentials.")

        if user.is_locked():
            raise serializers.ValidationError("Account temporarily locked. Try again later.")

        if not user.check_password(attrs["password"]):
            user.failed_login_attempts += 1
            if user.failed_login_attempts >= LOCKOUT_THRESHOLD:
                user.locked_until = timezone.now() + timedelta(minutes=LOCKOUT_DURATION_MIN)
            user.save(update_fields=["failed_login_attempts", "locked_until"])
            raise serializers.ValidationError("Invalid credentials.")

        user.failed_login_attempts = 0
        user.save(update_fields=["failed_login_attempts"])
        attrs["user"] = user
        return attrs


class VerifyOTPSerializer(serializers.Serializer):
    phone_number = serializers.CharField()
    code = serializers.CharField(max_length=6, min_length=6)
    purpose = serializers.ChoiceField(choices=["login", "registration", "withdrawal", "password_reset"])

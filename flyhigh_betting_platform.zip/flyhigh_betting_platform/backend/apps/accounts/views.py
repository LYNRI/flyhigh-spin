from django.contrib.auth import get_user_model
from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken

from .serializers import RegisterSerializer, LoginSerializer, VerifyOTPSerializer
from .otp_service import generate_otp, verify_otp, send_otp_sms
from .sms_providers.africastalking import SMSDeliveryError

User = get_user_model()


class RegisterView(APIView):
    permission_classes = [AllowAny]
    throttle_scope = "login"

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()

        code = generate_otp(user, purpose="registration")
        try:
            send_otp_sms(user.phone_number, code)
        except SMSDeliveryError:
            return Response(
                {"detail": "Registered, but the verification SMS couldn't be sent. Try resending the code."},
                status=status.HTTP_201_CREATED,
            )

        return Response(
            {"message": "Registered. Enter the OTP sent to your phone to activate your account."},
            status=status.HTTP_201_CREATED,
        )


class LoginView(APIView):
    """Step 1 of login: verify password, issue an OTP as second factor."""
    permission_classes = [AllowAny]
    throttle_scope = "login"

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data["user"]

        if not user.is_active:
            return Response({"detail": "Account not activated."}, status=status.HTTP_403_FORBIDDEN)
        if user.is_self_excluded():
            return Response({"detail": "Account is under self-exclusion."}, status=status.HTTP_403_FORBIDDEN)

        code = generate_otp(user, purpose="login")
        try:
            send_otp_sms(user.phone_number, code)
        except SMSDeliveryError:
            return Response({"detail": "Couldn't send the login code. Please try again shortly."}, status=502)

        return Response({"message": "OTP sent. Submit it to /verify-otp/ to complete login."})


class VerifyOTPView(APIView):
    """Step 2 of login/registration: verify OTP, issue JWT pair."""
    permission_classes = [AllowAny]
    throttle_scope = "otp_verify"

    def post(self, request):
        serializer = VerifyOTPSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        try:
            user = User.objects.get(phone_number=data["phone_number"])
        except User.DoesNotExist:
            return Response({"detail": "Invalid request."}, status=status.HTTP_400_BAD_REQUEST)

        if not verify_otp(user, data["purpose"], data["code"]):
            return Response({"detail": "Invalid or expired code."}, status=status.HTTP_400_BAD_REQUEST)

        if data["purpose"] == "registration":
            user.is_active = True
            user.is_phone_verified = True
            user.save(update_fields=["is_active", "is_phone_verified"])

        refresh = RefreshToken.for_user(user)
        return Response({
            "access": str(refresh.access_token),
            "refresh": str(refresh),
        })

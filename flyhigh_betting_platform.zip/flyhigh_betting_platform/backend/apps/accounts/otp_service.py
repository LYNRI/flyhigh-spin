import hashlib
import secrets
from datetime import timedelta
from django.utils import timezone
from .models import OTPCode

OTP_LENGTH = 6
OTP_TTL_MINUTES = 5


def _hash_code(code: str) -> str:
    return hashlib.sha256(code.encode()).hexdigest()


def generate_otp(user, purpose: str) -> str:
    """Create and store a hashed OTP, return the raw code for sending via SMS."""
    code = "".join(secrets.choice("0123456789") for _ in range(OTP_LENGTH))
    OTPCode.objects.create(
        user=user,
        code_hash=_hash_code(code),
        purpose=purpose,
        expires_at=timezone.now() + timedelta(minutes=OTP_TTL_MINUTES),
    )
    return code


def verify_otp(user, purpose: str, submitted_code: str) -> bool:
    otp = (
        OTPCode.objects.filter(user=user, purpose=purpose, consumed_at__isnull=True)
        .order_by("-created_at")
        .first()
    )
    if not otp or not otp.is_valid():
        return False

    otp.attempts += 1
    otp.save(update_fields=["attempts"])

    if secrets.compare_digest(otp.code_hash, _hash_code(submitted_code)):
        otp.consumed_at = timezone.now()
        otp.save(update_fields=["consumed_at"])
        return True
    return False


def send_otp_sms(phone_number: str, code: str):
    """
    Sends the OTP via Africa's Talking. Never log the raw code in production —
    if delivery fails, surface a generic error to the user, not the code itself.

    LOCAL DEV: with DEBUG=True and no AT_API_KEY configured, this prints the
    code to the console instead of calling the real API, so you can log in
    without an SMS provider. Remove this branch (or make sure DEBUG=False)
    before deploying anywhere real — printing OTPs is a dev-only convenience.
    """
    from django.conf import settings

    if settings.DEBUG and not settings.AFRICAS_TALKING.get("API_KEY"):
        print(f"\n[DEV OTP] {phone_number} -> {code}\n")
        return

    from .sms_providers.africastalking import send_sms

    message = f"Your verification code is {code}. It expires in {OTP_TTL_MINUTES} minutes. Do not share this code."
    send_sms(phone_number, message)

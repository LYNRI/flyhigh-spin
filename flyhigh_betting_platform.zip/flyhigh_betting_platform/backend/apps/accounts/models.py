import uuid
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone


class User(AbstractUser):
    """
    Phone number is the primary identifier (M-Pesa is phone-based).
    Email stays optional.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    phone_number = models.CharField(max_length=15, unique=True, db_index=True)
    is_phone_verified = models.BooleanField(default=False)
    is_kyc_verified = models.BooleanField(default=False)
    national_id_number = models.CharField(max_length=20, blank=True, null=True)
    date_of_birth = models.DateField(null=True, blank=True)

    # security / responsible-gambling controls
    failed_login_attempts = models.PositiveIntegerField(default=0)
    locked_until = models.DateTimeField(null=True, blank=True)
    self_exclusion_until = models.DateTimeField(null=True, blank=True)
    daily_deposit_limit = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)

    USERNAME_FIELD = "phone_number"
    REQUIRED_FIELDS = ["username"]

    def is_locked(self):
        return bool(self.locked_until and self.locked_until > timezone.now())

    def is_self_excluded(self):
        return bool(self.self_exclusion_until and self.self_exclusion_until > timezone.now())

    def __str__(self):
        return self.phone_number


class OTPCode(models.Model):
    """Short-lived one-time codes for login verification and sensitive actions."""

    PURPOSE_CHOICES = [
        ("login", "Login"),
        ("withdrawal", "Withdrawal"),
        ("registration", "Registration"),
        ("password_reset", "Password Reset"),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="otp_codes")
    code_hash = models.CharField(max_length=128)  # never store the raw code
    purpose = models.CharField(max_length=20, choices=PURPOSE_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    consumed_at = models.DateTimeField(null=True, blank=True)
    attempts = models.PositiveSmallIntegerField(default=0)

    def is_valid(self):
        return self.consumed_at is None and self.expires_at > timezone.now() and self.attempts < 5

    class Meta:
        indexes = [models.Index(fields=["user", "purpose", "expires_at"])]

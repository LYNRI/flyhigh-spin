from django.urls import path
from .views import RoundHistoryView, VerifyRoundView

urlpatterns = [
    path("history/", RoundHistoryView.as_view(), name="aviator-history"),
    path("verify/", VerifyRoundView.as_view(), name="aviator-verify"),
]

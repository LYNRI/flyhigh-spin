import json
from decimal import Decimal
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.db import transaction as db_transaction

from apps.wallet.models import Wallet, Transaction
from .models import AviatorRound, AviatorBet

ROOM_GROUP = "aviator_room"


class AviatorConsumer(AsyncWebsocketConsumer):
    """
    One round loop (see apps/games/aviator/round_worker.py, run via Celery/async
    task, not per-connection) publishes multiplier ticks and crash events to
    ROOM_GROUP. Each connected client just listens + sends bet/cashout actions.
    """

    async def connect(self):
        # Anyone can watch the live round (spectator mode for the public
        # dashboard). Only placing bets / cashing out requires a real user —
        # enforced in handle_place_bet / handle_cash_out below.
        await self.channel_layer.group_add(ROOM_GROUP, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(ROOM_GROUP, self.channel_name)

    async def receive(self, text_data):
        data = json.loads(text_data)
        action = data.get("action")

        if action == "place_bet":
            await self.handle_place_bet(data)
        elif action == "cash_out":
            await self.handle_cash_out(data)

    async def handle_place_bet(self, data):
        if self.scope["user"].is_anonymous:
            return await self.send_error("Log in to place a bet.")
        try:
            stake = Decimal(str(data["stake"]))
            round_id = data["round_id"]
        except (KeyError, TypeError):
            return await self.send_error("Invalid bet payload.")

        ok, message, bet_id = await self._place_bet(self.scope["user"], round_id, stake, data.get("auto_cashout_at"))
        await self.send(text_data=json.dumps({
            "type": "bet_ack", "ok": ok, "message": message, "bet_id": bet_id,
        }))

    async def handle_cash_out(self, data):
        if self.scope["user"].is_anonymous:
            return await self.send_error("Log in to cash out.")
        ok, message, payout = await self._cash_out(self.scope["user"], data.get("bet_id"), data.get("multiplier"))
        await self.send(text_data=json.dumps({
            "type": "cashout_ack", "ok": ok, "message": message, "payout": str(payout) if payout else None
        }))

    # --- group event handlers (called via channel_layer.group_send from the round worker) ---

    async def round_open(self, event):
        await self.send(text_data=json.dumps({
            "type": "round_open",
            "round_id": event["round_id"],
            "server_seed_hash": event["server_seed_hash"],
            "betting_window": event["betting_window"],
        }))

    async def round_started(self, event):
        await self.send(text_data=json.dumps({"type": "round_started", "round_id": event["round_id"]}))

    async def round_tick(self, event):
        await self.send(text_data=json.dumps({"type": "tick", "multiplier": event["multiplier"]}))

    async def round_crashed(self, event):
        await self.send(text_data=json.dumps({"type": "crashed", "crash_point": event["crash_point"]}))

    async def round_revealed(self, event):
        await self.send(text_data=json.dumps({
            "type": "round_revealed",
            "round_id": event["round_id"],
            "server_seed": event["server_seed"],
            "crash_point": event["crash_point"],
        }))

    async def send_error(self, message):
        await self.send(text_data=json.dumps({"type": "error", "message": message}))

    # --- DB access wrapped for async context ---

    @database_sync_to_async
    def _place_bet(self, user, round_id, stake, auto_cashout_at):
        try:
            round_obj = AviatorRound.objects.get(id=round_id, status="betting")
        except AviatorRound.DoesNotExist:
            return False, "Betting is closed for this round.", None

        with db_transaction.atomic():
            wallet = Wallet.objects.select_for_update().get(user=user)
            if wallet.available_balance() < stake:
                return False, "Insufficient balance.", None

            wallet.locked_balance += stake
            wallet.save(update_fields=["locked_balance"])

            bet = AviatorBet.objects.create(
                round=round_obj, user=user, stake=stake, auto_cashout_at=auto_cashout_at,
            )
            Transaction.objects.create(
                wallet=wallet, type="bet_stake", amount=stake, status="completed",
                reference=f"AV-{round_id}-{user.id}",
            )
        return True, "Bet placed.", str(bet.id)

    @database_sync_to_async
    def _cash_out(self, user, bet_id, current_multiplier):
        try:
            bet = AviatorBet.objects.select_related("round").get(
                id=bet_id, user=user, cashed_out_at__isnull=True, round__status="running"
            )
        except AviatorBet.DoesNotExist:
            return False, "No active bet to cash out.", None

        multiplier = Decimal(str(current_multiplier))
        payout = (bet.stake * multiplier).quantize(Decimal("0.01"))

        with db_transaction.atomic():
            wallet = Wallet.objects.select_for_update().get(user=user)
            # `balance` already includes the staked amount (placing a bet only
            # moves it into `locked_balance`, it doesn't debit balance). So on
            # a win we credit the *profit* (payout - stake), not the full
            # payout, and release the lock. On a loss (see round worker's
            # settle_round) we debit the stake itself and release the lock.
            wallet.balance += (payout - bet.stake)
            wallet.locked_balance -= bet.stake
            wallet.save(update_fields=["balance", "locked_balance"])

            bet.cashed_out_at = multiplier
            bet.payout = payout
            bet.save(update_fields=["cashed_out_at", "payout"])

            Transaction.objects.create(
                wallet=wallet, type="bet_payout", amount=payout, status="completed",
                reference=f"AV-PAYOUT-{bet.id}",
            )
        return True, "Cashed out.", payout

import asyncio
from django.core.management.base import BaseCommand
from apps.games.aviator.round_worker import AviatorEngine


class Command(BaseCommand):
    help = "Runs the Aviator dealer loop: opens rounds, ticks the multiplier, settles bets. Run exactly one instance."

    def handle(self, *args, **options):
        engine = AviatorEngine()
        self.stdout.write(self.style.SUCCESS("Aviator engine started. Ctrl+C to stop."))
        try:
            asyncio.run(engine.run_forever())
        except KeyboardInterrupt:
            self.stdout.write(self.style.WARNING("Aviator engine stopped."))

import uuid
from django.conf import settings
from django.db import models


class AviatorRound(models.Model):
    STATUS_CHOICES = [
        ("betting", "Accepting Bets"),
        ("running", "In Flight"),
        ("crashed", "Crashed"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    server_seed = models.CharField(max_length=64)  # kept secret until round ends
    server_seed_hash = models.CharField(max_length=64)  # published before betting opens
    client_seed = models.CharField(max_length=64)  # can be derived from recent block hash / player input
    nonce = models.PositiveIntegerField()
    crash_point = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="betting")
    started_at = models.DateTimeField(auto_now_add=True)
    crashed_at = models.DateTimeField(null=True, blank=True)


class AviatorBet(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    round = models.ForeignKey(AviatorRound, on_delete=models.CASCADE, related_name="bets")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="aviator_bets")
    stake = models.DecimalField(max_digits=12, decimal_places=2)
    cashed_out_at = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    payout = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    auto_cashout_at = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    placed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [models.Index(fields=["round", "user"])]

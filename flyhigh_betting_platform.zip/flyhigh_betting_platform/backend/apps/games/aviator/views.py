from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import AviatorRound
from .engine import verify_round


class RoundHistoryView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        rounds = AviatorRound.objects.filter(status="crashed").order_by("-crashed_at")[:50]
        return Response([
            {
                "round_id": str(r.id),
                "crash_point": str(r.crash_point),
                "server_seed_hash": r.server_seed_hash,
                "server_seed": r.server_seed,  # only revealed after the round ends
                "client_seed": r.client_seed,
                "nonce": r.nonce,
            }
            for r in rounds
        ])


class VerifyRoundView(APIView):
    """Lets anyone independently confirm a past round wasn't rigged."""
    permission_classes = [AllowAny]

    def post(self, request):
        try:
            round_obj = AviatorRound.objects.get(id=request.data["round_id"], status="crashed")
        except (AviatorRound.DoesNotExist, KeyError):
            return Response({"detail": "Round not found."}, status=404)

        is_valid = verify_round(
            server_seed=round_obj.server_seed,
            client_seed=round_obj.client_seed,
            nonce=round_obj.nonce,
            published_hash=round_obj.server_seed_hash,
            claimed_crash=float(round_obj.crash_point),
        )
        return Response({"valid": is_valid})

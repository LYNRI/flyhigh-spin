"""
The Aviator "dealer" process. Run as a single long-lived worker:

    python manage.py run_aviator_engine

Do NOT run more than one instance — it owns round state. If you need
redundancy, put it behind a leader-election lock (e.g. a Redis lock) rather
than running it twice.

Loop: betting window -> flight (ticking multiplier) -> crash -> reveal -> repeat.
Every tick and event is pushed to the `aviator_room` channel group, which the
AviatorConsumer (apps/games/aviator/consumers.py) forwards to each connected
browser. Players' bet/cashout actions go through the consumer and hit the
DB directly — the round worker doesn't need to know about individual sockets.
"""
import asyncio
import math
import secrets
import time

from asgiref.sync import sync_to_async
from channels.layers import get_channel_layer
from django.db import transaction as db_transaction

from apps.wallet.models import Wallet, Transaction
from apps.games.aviator.models import AviatorRound, AviatorBet
from apps.games.aviator.engine import generate_server_seed, commit_seed, compute_crash_point

BETTING_WINDOW_SECONDS = 5
TICK_INTERVAL_SECONDS = 0.1
POST_CRASH_PAUSE_SECONDS = 3
ROOM_GROUP = "aviator_room"

# How fast the multiplier climbs — tune to taste. This is a smooth
# exponential curve; players watch `growth_rate` compound each second.
GROWTH_RATE = 0.06


def multiplier_at(elapsed_seconds: float) -> float:
    return round(math.exp(GROWTH_RATE * elapsed_seconds * 10), 2)


class AviatorEngine:
    def __init__(self):
        self.channel_layer = get_channel_layer()
        self.nonce = 0

    async def run_forever(self):
        while True:
            await self.run_one_round()

    async def run_one_round(self):
        self.nonce += 1
        server_seed = generate_server_seed()
        server_seed_hash = commit_seed(server_seed)
        client_seed = secrets.token_hex(8)  # could be derived from a public entropy source instead

        round_obj = await self._create_round(server_seed, server_seed_hash, client_seed, self.nonce)
        crash_point = compute_crash_point(server_seed, client_seed, self.nonce)

        # --- betting window ---
        await self._broadcast("round_open", {
            "round_id": str(round_obj.id),
            "server_seed_hash": server_seed_hash,
            "betting_window": BETTING_WINDOW_SECONDS,
        })
        await asyncio.sleep(BETTING_WINDOW_SECONDS)

        await self._set_status(round_obj, "running")
        await self._broadcast("round_started", {"round_id": str(round_obj.id)})

        # --- flight: tick until we hit the predetermined crash point ---
        start = time.monotonic()
        current_multiplier = 1.00
        while current_multiplier < crash_point:
            elapsed = time.monotonic() - start
            current_multiplier = min(multiplier_at(elapsed), crash_point)

            await self._auto_cashout_eligible_bets(round_obj, current_multiplier)
            await self.channel_layer.group_send(ROOM_GROUP, {
                "type": "round_tick", "multiplier": current_multiplier,
            })
            await asyncio.sleep(TICK_INTERVAL_SECONDS)

        # --- crash ---
        await self._crash_round(round_obj, crash_point)
        await self.channel_layer.group_send(ROOM_GROUP, {
            "type": "round_crashed", "crash_point": crash_point,
        })
        await self._broadcast("round_revealed", {
            "round_id": str(round_obj.id),
            "server_seed": server_seed,  # safe to reveal now that the round is over
            "crash_point": crash_point,
        })

        await asyncio.sleep(POST_CRASH_PAUSE_SECONDS)

    async def _broadcast(self, event_type, payload):
        await self.channel_layer.group_send(ROOM_GROUP, {"type": event_type, **payload})

    @sync_to_async
    def _create_round(self, server_seed, server_seed_hash, client_seed, nonce):
        return AviatorRound.objects.create(
            server_seed=server_seed,
            server_seed_hash=server_seed_hash,
            client_seed=client_seed,
            nonce=nonce,
            status="betting",
        )

    @sync_to_async
    def _set_status(self, round_obj, status):
        round_obj.status = status
        round_obj.save(update_fields=["status"])

    @sync_to_async
    def _auto_cashout_eligible_bets(self, round_obj, current_multiplier):
        eligible = AviatorBet.objects.filter(
            round=round_obj, cashed_out_at__isnull=True,
            auto_cashout_at__isnull=False, auto_cashout_at__lte=current_multiplier,
        ).select_related("user")

        for bet in eligible:
            with db_transaction.atomic():
                wallet = Wallet.objects.select_for_update().get(user=bet.user)
                payout = round(float(bet.stake) * float(bet.auto_cashout_at), 2)

                wallet.balance += (payout - float(bet.stake))
                wallet.locked_balance -= bet.stake
                wallet.save(update_fields=["balance", "locked_balance"])

                bet.cashed_out_at = bet.auto_cashout_at
                bet.payout = payout
                bet.save(update_fields=["cashed_out_at", "payout"])

                Transaction.objects.create(
                    wallet=wallet, type="bet_payout", amount=payout, status="completed",
                    reference=f"AV-AUTOPAYOUT-{bet.id}",
                )

    @sync_to_async
    def _crash_round(self, round_obj, crash_point):
        round_obj.status = "crashed"
        round_obj.crash_point = crash_point
        round_obj.save(update_fields=["status", "crash_point"])

        # anyone still holding an open bet loses their stake
        losers = AviatorBet.objects.filter(round=round_obj, cashed_out_at__isnull=True).select_related("user")
        for bet in losers:
            with db_transaction.atomic():
                wallet = Wallet.objects.select_for_update().get(user=bet.user)
                wallet.balance -= bet.stake
                wallet.locked_balance -= bet.stake
                wallet.save(update_fields=["balance", "locked_balance"])
                bet.payout = 0
                bet.save(update_fields=["payout"])

import uuid

import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="AviatorRound",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("server_seed", models.CharField(max_length=64)),
                ("server_seed_hash", models.CharField(max_length=64)),
                ("client_seed", models.CharField(max_length=64)),
                ("nonce", models.PositiveIntegerField()),
                ("crash_point", models.DecimalField(blank=True, decimal_places=2, max_digits=8, null=True)),
                (
                    "status",
                    models.CharField(
                        choices=[("betting", "Accepting Bets"), ("running", "In Flight"), ("crashed", "Crashed")],
                        default="betting",
                        max_length=10,
                    ),
                ),
                ("started_at", models.DateTimeField(auto_now_add=True)),
                ("crashed_at", models.DateTimeField(blank=True, null=True)),
            ],
        ),
        migrations.CreateModel(
            name="AviatorBet",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("stake", models.DecimalField(decimal_places=2, max_digits=12)),
                ("cashed_out_at", models.DecimalField(blank=True, decimal_places=2, max_digits=8, null=True)),
                ("payout", models.DecimalField(blank=True, decimal_places=2, max_digits=12, null=True)),
                ("auto_cashout_at", models.DecimalField(blank=True, decimal_places=2, max_digits=8, null=True)),
                ("placed_at", models.DateTimeField(auto_now_add=True)),
                (
                    "round",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="bets",
                        to="aviator.aviatorround",
                    ),
                ),
                (
                    "user",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="aviator_bets",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
        ),
        migrations.AddIndex(
            model_name="aviatorbet",
            index=models.Index(fields=["round", "user"], name="aviator_bet_round_user_idx"),
        ),
    ]

"""
Provably-fair crash point generation.

The server commits to a secret seed *before* the round by publishing its hash.
After the round, the server reveals the seed so players can recompute the
crash point themselves and verify it wasn't changed after bets were placed.
"""
import hashlib
import hmac
import secrets

HOUSE_EDGE = 0.03  # 3% — tune to your target RTP


def generate_server_seed() -> str:
    return secrets.token_hex(32)


def commit_seed(server_seed: str) -> str:
    """Published to players before the round starts."""
    return hashlib.sha256(server_seed.encode()).hexdigest()


def compute_crash_point(server_seed: str, client_seed: str, nonce: int) -> float:
    """
    Deterministic function of (server_seed, client_seed, nonce) -> crash multiplier.
    Same inputs always produce the same output, so it's independently verifiable.
    """
    h = hmac.new(server_seed.encode(), f"{client_seed}:{nonce}".encode(), hashlib.sha256).hexdigest()
    # take first 13 hex chars as an integer for uniform distribution
    int_val = int(h[:13], 16)
    max_val = 2 ** 52

    # standard crash-game distribution skewed by house edge; instant-crash (1.00x) floor
    if int_val % 33 == 0:  # ~3% instant-crash chance, tune to taste
        return 1.00

    result = (max_val * (1 - HOUSE_EDGE)) / (max_val - int_val)
    return max(1.00, round(result, 2))


def verify_round(server_seed: str, client_seed: str, nonce: int, published_hash: str, claimed_crash: float) -> bool:
    """What a player/auditor runs after the round to confirm fairness."""
    if commit_seed(server_seed) != published_hash:
        return False
    return compute_crash_point(server_seed, client_seed, nonce) == claimed_crash

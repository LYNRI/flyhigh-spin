from django.apps import AppConfig


class AviatorConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.games.aviator"
    label = "aviator"

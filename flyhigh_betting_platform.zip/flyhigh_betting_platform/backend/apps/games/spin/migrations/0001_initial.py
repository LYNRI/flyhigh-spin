import uuid

import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="SpinResult",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("server_seed", models.CharField(max_length=64)),
                ("server_seed_hash", models.CharField(max_length=64)),
                ("client_seed", models.CharField(max_length=64)),
                ("nonce", models.PositiveIntegerField()),
                ("stake", models.DecimalField(decimal_places=2, max_digits=12)),
                ("reels", models.JSONField()),
                ("payout", models.DecimalField(decimal_places=2, max_digits=12)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                (
                    "user",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="spin_results",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
        ),
        migrations.AddIndex(
            model_name="spinresult",
            index=models.Index(fields=["user", "created_at"], name="spin_result_user_created_idx"),
        ),
    ]

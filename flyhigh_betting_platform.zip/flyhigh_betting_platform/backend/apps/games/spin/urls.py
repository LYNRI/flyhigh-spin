from django.urls import path
from .views import SpinView

urlpatterns = [
    path("play/", SpinView.as_view(), name="spin-play"),
]

import secrets
from decimal import Decimal
from django.db import transaction as db_transaction
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.wallet.models import Wallet, Transaction
from .engine import spin_reels, calculate_payout
from .models import SpinResult

MIN_STAKE = Decimal("10")


class SpinView(APIView):
    permission_classes = [IsAuthenticated]
    throttle_scope = "bet_place"

    def post(self, request):
        stake = Decimal(str(request.data.get("stake", 0)))
        client_seed = request.data.get("client_seed", secrets.token_hex(8))

        if stake < MIN_STAKE:
            return Response({"detail": f"Minimum stake is KES {MIN_STAKE}."}, status=400)

        with db_transaction.atomic():
            wallet = Wallet.objects.select_for_update().get(user=request.user)
            if wallet.available_balance() < stake:
                return Response({"detail": "Insufficient balance."}, status=400)

            server_seed = secrets.token_hex(32)
            server_seed_hash = __import__("hashlib").sha256(server_seed.encode()).hexdigest()
            nonce = SpinResult.objects.filter(user=request.user).count() + 1

            reels = spin_reels(server_seed, client_seed, nonce)
            payout = Decimal(str(calculate_payout(reels, float(stake))))

            wallet.balance = wallet.balance - stake + payout
            wallet.save(update_fields=["balance"])

            Transaction.objects.create(
                wallet=wallet, type="bet_stake", amount=stake, status="completed",
                reference=f"SPIN-STAKE-{nonce}-{request.user.id}",
            )
            if payout > 0:
                Transaction.objects.create(
                    wallet=wallet, type="bet_payout", amount=payout, status="completed",
                    reference=f"SPIN-PAYOUT-{nonce}-{request.user.id}",
                )

            result = SpinResult.objects.create(
                user=request.user, server_seed=server_seed, server_seed_hash=server_seed_hash,
                client_seed=client_seed, nonce=nonce, stake=stake, reels=reels, payout=payout,
            )

        return Response({
            "reels": reels,
            "payout": str(payout),
            "server_seed": server_seed,       # revealed immediately since spin is instant, not a multi-bet round
            "server_seed_hash": server_seed_hash,
            "client_seed": client_seed,
            "nonce": nonce,
            "new_balance": str(wallet.balance),
        })

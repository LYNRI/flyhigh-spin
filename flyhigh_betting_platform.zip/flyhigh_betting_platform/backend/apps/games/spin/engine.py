"""
Provably-fair slot spin engine. Same commit-reveal pattern as Aviator:
publish server_seed_hash before the spin, reveal server_seed after.
"""
import hashlib
import hmac

SYMBOLS = ["cherry", "lemon", "bell", "star", "seven", "diamond"]

# Payout multiplier for three-of-a-kind, per symbol. Tune against target RTP.
PAYTABLE = {
    "cherry": 2,
    "lemon": 3,
    "bell": 5,
    "star": 10,
    "seven": 25,
    "diamond": 50,
}


def spin_reels(server_seed: str, client_seed: str, nonce: int, reel_count: int = 3) -> list:
    """Deterministic reel outcome from the seed triple."""
    result = []
    for i in range(reel_count):
        h = hmac.new(server_seed.encode(), f"{client_seed}:{nonce}:{i}".encode(), hashlib.sha256).hexdigest()
        index = int(h[:8], 16) % len(SYMBOLS)
        result.append(SYMBOLS[index])
    return result


def calculate_payout(reels: list, stake) -> float:
    if len(set(reels)) == 1:
        return stake * PAYTABLE[reels[0]]
    # two matching symbols pays a small consolation, tune to taste
    if len(set(reels)) == 2:
        return stake * 0.5
    return 0

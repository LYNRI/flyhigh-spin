from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/auth/", include("apps.accounts.urls")),
    path("api/wallet/", include("apps.wallet.urls")),
    path("api/games/aviator/", include("apps.games.aviator.urls")),
    path("api/games/spin/", include("apps.games.spin.urls")),
]

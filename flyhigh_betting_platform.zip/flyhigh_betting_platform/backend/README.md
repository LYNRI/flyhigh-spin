# Betting Platform — Project Skeleton

Django backend for a real-money betting platform: Aviator (crash game), a
spin/slots game, M-Pesa deposits/withdrawals, and phone+OTP authentication.

## Layout

```
betting_platform/
  betting_platform/        settings, root urls, wsgi/asgi
  apps/
    accounts/               custom user, OTP login (2FA), registration
    wallet/                 balance ledger + M-Pesa Daraja integration
    games/
      aviator/               provably-fair crash game, WebSocket live multiplier
      spin/                  provably-fair slot spins (REST, instant results)
```

## Getting started

```bash
cp .env.example .env        # fill in real DB/Redis/M-Pesa/SMS credentials
docker compose up --build
docker compose exec web python manage.py migrate
docker compose exec web python manage.py createsuperuser
```

Frontend is not included here — build a React/Next.js (or Vue) SPA against
these REST + WebSocket endpoints. A responsive layout covers both PC and
mobile web from one codebase; wrap it as a PWA for an installable mobile feel.

## What's implemented (skeleton-level)

- **Auth**: registration, password + SMS-OTP two-factor login, account
  lockout after repeated failures, JWT access/refresh tokens.
- **Wallet**: append-only transaction ledger, M-Pesa STK Push (deposit) and
  B2C (withdrawal) integration with idempotent callback handlers.
- **Aviator**: provably-fair crash-point algorithm (commit-reveal hash
  scheme), WebSocket consumer for bet placement / live cashout.
- **Spin**: provably-fair slot RNG, single REST endpoint per spin.

## What you still need to build before going live

1. **The Aviator round loop itself** — a scheduled worker (Celery beat /
   asyncio task) that opens betting, runs the multiplier tick, auto-cashes
   out bets that hit their target, and broadcasts to the WebSocket group.
   The consumer here handles the player side; the round loop is the "dealer."
2. **SMS provider wiring** — `apps/accounts/otp_service.send_otp_sms` is a
   stub; connect it to Africa's Talking, Safaricom SMS API, or similar.
3. **Real M-Pesa credentials** — Daraja sandbox works for testing; going
   live means Safaricom approval, which typically requires your BCLB
   betting license first.
4. **Frontend** — React/Next.js SPA, responsive for PC + mobile.
5. **Admin/ops tooling** — reconciliation reports, suspicious-activity
   flags, responsible-gambling limits enforcement (self-exclusion,
   deposit limits are modeled on the User but not yet enforced everywhere).
6. **Load testing** on the Aviator WebSocket path — many concurrent
   connections need one multiplier broadcast, not one loop per connection.
7. **Security review** — penetration testing before handling real money;
   this skeleton follows good practice (hashed OTPs, atomic wallet updates,
   idempotent payment callbacks) but hasn't been audited.

## Kenyan regulatory note

Real-money betting requires a license from the **Betting Control and
Licensing Board (BCLB)**. Sort this in parallel with development — it
gates Safaricom's production Daraja API access too.
